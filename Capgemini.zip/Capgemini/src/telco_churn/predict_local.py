import json, requests

"""with open("C:/Users/Javichu/OneDrive - UFV/Escritorio/personal/Capgemini/Capgemini/src/telco_churn/input.json", "r") as f:
    data = json.load(f)

r = requests.post(
    "http://127.0.0.1:1234/invocations",
    json=data,
    headers={"Content-Type": "application/json"},
    timeout=30,
)

print("HTTP:", r.status_code)
try:
    print("✅ Predicción:", r.json())
except Exception:
    print("🔎 Respuesta cruda:", r.text[:500])"""
    
import json, requests

url = "http://127.0.0.1:1234/invocations"

# Lee tu input.json actual (con "inputs": [ {...} ])
with open("C:/Users/Javichu/OneDrive - UFV/Escritorio/personal/Capgemini/Capgemini/src/telco_churn/input.json", "r") as f:
    data = json.load(f)

# Adaptamos al protocolo MLflow 2.x
payload = {"dataframe_records": data["inputs"]}

r = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=30)
print("HTTP:", r.status_code)
try:
    print("Body:", r.json())
except Exception:
    print("Body:", r.text[:500])


